create function sys_tbc_user_buscar(concatenar text)
  returns TABLE(iduser integer, nomcompleto text)
language sql
as $$
select N_IdUser,CONCAT(V_Nombres,' ',V_Paterno,' ',V_Materno) as nomcompleto
from "SYS"."TBC_USER"
where V_Nombres||' '||V_Paterno||' '||V_materno like '%'||concatenar||'%'

$$;

