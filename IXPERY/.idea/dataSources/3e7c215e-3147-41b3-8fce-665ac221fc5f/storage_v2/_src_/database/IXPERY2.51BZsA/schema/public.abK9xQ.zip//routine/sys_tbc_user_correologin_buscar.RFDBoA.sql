create function sys_tbc_user_correologin_buscar(valor text)
  returns TABLE(login character varying, nombres character varying, "Apellido Paterno" character varying, "Apellido Materno" character varying, estado bit, clave character varying, idpersonal integer, correo character varying)
language sql
as $$
select V_Login as "Login" ,V_Nombres as "Nombres",V_Paterno as "Apellido Paterno",V_Materno as "Apellido Materno",
S_Estado as "Estado",V_Clave as "Clave", N_IdPersonal as "IdPersonal", V_Correo as "Correo"
from "SYS"."TBC_USER"
where valor = V_Login or valor= V_Correo

$$;

