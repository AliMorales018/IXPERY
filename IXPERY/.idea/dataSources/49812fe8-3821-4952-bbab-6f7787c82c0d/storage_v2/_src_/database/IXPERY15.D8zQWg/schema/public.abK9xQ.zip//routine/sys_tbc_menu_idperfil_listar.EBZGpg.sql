create function sys_tbc_menu_idperfil_listar(idperfil integer)
  returns TABLE("IdPerfil" integer, "IdMenu" integer, "Descripcion" character varying, "IdPadre" integer, "Posicion" integer, "Icono" character varying, "Habilitado" bit, "Url" character varying, "IdApli" integer)
language plpgsql
as $$
begin
select mp.N_IdPerfil as "IdPerfil", m.N_IdMenu as "IdMenu", m.V_Descripcion as "Descripcion",
m.N_IdPadre as "IdPadre", m.N_Posicion as "Posicion", m.V_Icono as "Icono",
m.S_Habilitado as "Habilitado", m.V_Url as "Url", m.N_IdApli as "IdApli"   
from "SYS"."TBC_MENU" m inner join "SYS"."TBD_MENUPERFIL" mp on m.N_IdMenu =mp.N_IdMenu 
where N_IdPerfil=idperfil;
end

$$;

