create function sys_tbc_perfildescripcionmenu_listar()
  returns TABLE("IdPerfil" integer, "Descripcion" text)
language plpgsql
as $$
begin
select mp.N_IdPerfil "IdPerfil", m.V_Descripcion "Descripcion"   
from "SYS"."TBC_MENU" m inner join "SYS"."TBD_MENUPERFIL" mp on m.N_IdMenu =mp.N_IdMenu;
end

$$;

