create function insertar_pregistroproducto(cadena text)
  returns text
language plpgsql
as $$
declare 
numtbl int;
data_json text;
idpp int;
cadena2 text;
begin

numtbl=(select distinct idtabla from tabla_general where tabla='TBC_PREREGISTROPRODUCTO');

idpp=(select gen_retornaid(cast(numtbl as text)));
cadena2=(select concat(idpp,',',cadena));

data_json='
insert into "LOG"."TBC_PREREGISTROPRODUCTO" (n_idprereg,n_idprodsol,n_idproducto)
values ('||cadena2||')';
execute(data_json);

return cadena2;
end

$$;

