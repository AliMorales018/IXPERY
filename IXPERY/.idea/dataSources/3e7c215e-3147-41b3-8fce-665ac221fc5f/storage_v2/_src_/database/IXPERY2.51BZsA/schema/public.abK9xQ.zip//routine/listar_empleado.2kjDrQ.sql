create function listar_empleado()
  returns text
language plpgsql
as $$
declare
data_json text;
begin
IF(select COUNT(*) FROM "RHH"."TBC_EMPLEADO"
				WHERE s_estado='1')>0 THEN 
data_json:=(
	select concat('[', 
		(select string_agg(registros||'',',') from (
			select row_to_json(a) as registros from (

				select n_idempleado as IDEMPLEADO,v_nombre as NOMEMPLEADO,v_apellidopaterno as APPATERNO,v_apellidomaterno AS APMATERNO
				FROM "RHH"."TBC_EMPLEADO"
				WHERE s_estado='1'
				
				)a
			)s
		 )
	 ,']')
	);
ELSE data_json=0;
END IF;

return data_json;
end

$$;

