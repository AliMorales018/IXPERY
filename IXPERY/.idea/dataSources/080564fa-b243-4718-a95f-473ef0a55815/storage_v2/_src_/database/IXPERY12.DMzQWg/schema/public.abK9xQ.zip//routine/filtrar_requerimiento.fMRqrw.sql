create function filtrar_requerimiento(integer, character varying)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
if (select count(*) FROM "LOG"."TBC_REQUERIMIENTO"
				 WHERE  n_idproyecto=$1 and v_nomrequerimiento like '%'||$2||'%')>0 then
data_json:=(
	select concat('{"46061":','[', 
		(select string_agg(registros||'',',') from (
			select row_to_json(a) as registros from (	
				
					select n_idrequerimiento as "460611",(select row_to_json(a) from(
														 select distinct n_idproyecto as "460511"
														from "LOG"."TBC_PROYECTO" where n_idproyecto=$1 )a ) as "460612",
							v_nomrequerimiento as "460613",s_estado as "460615", n_idestado as "460616"
					from "LOG"."TBC_REQUERIMIENTO" WHERE  n_idproyecto=$1 and v_nomrequerimiento like '%'||$2||'%'
				)a
			)s
		 )
	 ,']}')
	);
else data_json=0;
	
end if;
return data_json;
end

$$;

