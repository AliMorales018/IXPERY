create function gen_where2(nomtabla text, campos text)
  returns text
language plpgsql
as $$
DECLARE
consulta varchar(4000);
condicion text;
i int;
j int;

BEGIN

i:=1;
condicion:='';

while (select length(split_part(campos,';',i)))>1
loop
	if(
		select tipo_dato from tabla_general
			where idcampo=(select split_part ((select split_part(campos,';',i)),',',1)
			) and tabla= nomtabla
		) in ('integer', 'money') then

		condicion:=condicion||(select concat ('"',(select split_part ((select split_part(campos,';',i)),',',1)),'"'))
		||'='
		||(select split_part ((select split_part(campos,';',i)),',',2))
		||' and ';
		
	
	else 
		condicion:=condicion||(select concat ('"',(select split_part ((select replace ((select split_part(campos,';',i)),',','=')),'=',1)),'"'))
		||'='
		||(select concat (chr(39),(select split_part ((select replace ((select split_part(campos,';',i)),',','=')),'=',2)),chr(39)))
		||' and ';
		
				
		
	end if;
i:=i+1;
end loop;
condicion:= substring (condicion,1,length(condicion)-4);
return condicion;
END;

$$;

