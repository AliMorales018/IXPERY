create function gen_tabla_json(nomtbl text, consulta text, OUT consultajson text)
  returns text
language plpgsql
as $$
declare 
cantfk int;
consultabuilobject text;
idcampofkcab text;
campofk text;
idcampofkdet text;
camposaliasnofk text;
consultafin text;
i int;

begin

execute(consulta);

--fin crear tabla temmporal
--generar json_build_object--------------------------------------------------------------------------------
cantfk:=(select COUNT(*) from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint='FOREIGN KEY');
i:=1;
consultabuilobject:='';

while cantfk>=i
loop

idcampofkcab:=(select split_part (
					(select string_agg(idcampo||'',',') from (
						select idcampo
						from tabla_constraint() tc
						inner join tabla_general tg on tc.nom_campo=tg.campo and tc.references_table=tg.tabla
						where nom_tabla=nomtbl and tipo_constraint='FOREIGN KEY'
						)t
			  		)
				,',',i));
				
campofk:=(select split_part (
				(select string_agg(campo||'',',') from (
				select campo
				from tabla_constraint() tc
				inner join tabla_general tg on tc.nom_campo=tg.campo and tc.nom_tabla=tg.tabla
				where nom_tabla=nomtbl and tipo_constraint='FOREIGN KEY'
			)t)
		,',',i));
		
idcampofkdet:=(select split_part(( select string_agg(idcampo||'',',') from (
					select idcampo
					from tabla_constraint() tc
					inner join tabla_general tg on tc.nom_campo=tg.campo and tc.nom_tabla=tg.tabla
					where nom_tabla=nomtbl and tipo_constraint='FOREIGN KEY'
				)t
		  ),',',i));
		
consultabuilobject:=consultabuilobject||', json_build_object('||chr(39)||idcampofkcab||chr(39)||',a.'||campofk||') as "'||idcampofkdet||'"';
i:=i+1;
end loop;

--fin generar json_build_object--------------------------------------------------------------------------------
--concatenar las no fk con alias
camposaliasnofk:=	(select (string_agg(campo||' as "'||idcampo||'"',',')) from (
					select campo, idcampo from tabla_general tg
					where tabla=nomtbl and campo not in (
						select nom_campo from tabla_general tg
						left join tabla_constraint() tc on tc.nom_campo=tg.campo and tc.nom_tabla=tg.tabla
						where tabla=nomtbl and tipo_constraint in('FOREIGN KEY')
						)
					)t
				 );
		
consultajson:='select (string_agg(fila_json||'||chr(39)||chr(39)||','||chr(39)||','||chr(39)||'))
				from (
						select row_to_json(u) as "fila_json"
					from(
						select '||camposaliasnofk;
						

consultafin:='from TBLTEMP a 
						)u
					)v;
					--DROP TABLE IF EXISTS TBLTEMP;';
					
consultajson:=consultajson
				||consultabuilobject
				||consultafin;

end;

$$;

