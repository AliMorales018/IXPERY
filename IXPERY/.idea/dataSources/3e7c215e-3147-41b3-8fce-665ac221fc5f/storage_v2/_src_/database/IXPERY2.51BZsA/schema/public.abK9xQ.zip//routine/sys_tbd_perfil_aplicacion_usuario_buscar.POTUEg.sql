create function sys_tbd_perfil_aplicacion_usuario_buscar(iduser integer, idaplicacion integer)
  returns TABLE("ID" integer, "PERFIL" character varying)
language plpgsql
as $$
declare
consulta text;
begin
return query
SELECT per.N_IdPerfil as "ID", per.V_Perfil as "PERFIL"
FROM "SYS"."TBC_USER" tu
INNER JOIN "SYS"."TBD_PERFILUSER" pu ON tu.N_IdUser = pu.N_IdUser
INNER JOIN "SYS"."TBC_PERFIL" per ON pu.N_IdPerfil = per.N_IdPerfil
INNER JOIN "SYS"."TBC_APLICACION" ap ON per.N_IdApli = ap.N_IdApli
WHERE (tu.N_IdUser = iduser) and tu.S_Estado='1' and ap.N_IdApli = idaplicacion and ap.S_Estado='1';
end

$$;

