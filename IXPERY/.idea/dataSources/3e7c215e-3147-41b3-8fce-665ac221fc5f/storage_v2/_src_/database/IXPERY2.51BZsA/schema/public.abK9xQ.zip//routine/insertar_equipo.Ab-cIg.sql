create function insertar_equipo(numero integer)
  returns text
language plpgsql
as $$
declare 
numtbl int;
data_json text;
ideq int;
cadena2 text;
begin

numtbl=(select distinct idtabla from tabla_general where tabla='TBC_EQUIPO');

ideq=(select gen_retornaid(cast(numtbl as text)));
cadena2=(select concat(ideq,',',numero));

data_json='
insert into "LOG"."TBC_EQUIPO" (n_idequipo,n_idsolucion)
values ('||cadena2||')';
execute(data_json);

return cadena2;
end
$$;

