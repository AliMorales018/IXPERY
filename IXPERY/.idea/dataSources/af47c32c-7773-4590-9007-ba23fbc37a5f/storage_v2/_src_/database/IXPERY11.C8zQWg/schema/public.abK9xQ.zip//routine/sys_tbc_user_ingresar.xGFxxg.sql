create function sys_tbc_user_ingresar(login character varying, clave character varying)
  returns integer
language plpgsql
as $$
declare
codigo integer;
begin 
codigo:=0;
	if (select count(*) from "SYS"."TBC_USER" where V_Login=login and V_Clave=clave  and S_Estado='1') >0 then 
		codigo:=(select n_iduser as "acceso" from "SYS"."TBC_USER" where V_Login=login and V_Clave=clave
		and S_Estado = '1');
	else
		codigo:=(select cast(codigo as text) as "acceso");
	end if;
	return codigo;
end;

$$;

