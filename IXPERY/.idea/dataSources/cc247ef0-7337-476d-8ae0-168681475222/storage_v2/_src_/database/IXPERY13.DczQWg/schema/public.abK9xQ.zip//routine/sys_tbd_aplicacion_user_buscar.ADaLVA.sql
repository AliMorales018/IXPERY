create function sys_tbd_aplicacion_user_buscar(iduser integer)
  returns TABLE("ID" integer, "APLICACION" character varying)
language plpgsql
as $$
begin
return query
SELECT distinct ap.N_IdApli as "ID", ap.V_Aplicacion as "APLICACION"
FROM "SYS"."TBC_APLICACION" ap
INNER JOIN "SYS"."TBC_PERFIL" per ON ap.N_IdApli = per.N_IdApli
INNER JOIN "SYS"."TBD_PERFILUSER" pu ON per.N_IdPerfil = pu.N_IdPerfil
INNER JOIn "SYS"."TBC_USER" tu ON pu.N_IdUser = tu.N_IdUser
WHERE (tu.N_IdUser = iduser) and tu.S_Estado='1' and ap.S_Estado='1';
end

$$;

