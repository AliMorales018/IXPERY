create function filtrar_producto_proveedor2(idprodprov integer)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
IF (select COUNT(*)
			from "LOG"."TBD_PRODUCTOPROVEEDOR" pp 
			inner join "LOG"."TBC_PRODUCTO" p on pp.n_idproducto=p.n_idproducto
			where n_idproveedor=idprodprov)>0 THEN
data_json:=(
	select concat('[', 
		(select string_agg(registros||'',',') from (
			select row_to_json(a) as registros from (
				
						select n_idproveedor as IDPRODPROV,p.n_idproducto AS IDPRODUCTO,v_nomproducto AS NOMPRODUCTO,
						v_modelo AS MODELO,v_marca AS MARCA
						from "LOG"."TBD_PRODUCTOPROVEEDOR" pp 
						inner join "LOG"."TBC_PRODUCTO" p on pp.n_idproducto=p.n_idproducto
						where n_idproveedor=idprodprov
				
				)a
			)s
		 )
	 ,']')
	);
	ELSE data_json=0;
	END IF;
	return data_json;
end

$$;

