create function sys_lista_menu_padre_hijos(idperfil integer)
  returns text
language plpgsql
as $$
declare
consulta text;
begin
consulta:=(
select concat ('[',(select (string_agg(fila||'',','))),']') from (
select row_to_json (a) as fila from (
SELECT  0 as ID, m.N_IdMenu as IdMenu, m.V_Descripcion as Descripcion, 
m.N_IdPadre as IdPadre, m.N_Posicion as Posicion, m.V_Icono as Icono, m.S_Habilitado as Habilitado, 
m.V_Url as Url, m.N_IdApli as IdApli
FROM            "SYS"."TBC_MENU" m inner join "SYS"."TBD_MENUPERFIL" mp on m.N_IdMenu= mp.N_IdMenu 
where m.N_IdMenu= m.N_IdPadre and mp.N_IdPerfil =idperfil
UNION all
select 1 as ID,m.N_IdMenu as IdMenu, m.V_Descripcion as Descripcion, 
m.N_IdPadre as IdPadre, m.N_Posicion as Posicion, m.V_Icono as Icono, m.S_Habilitado as Habilitado, 
m.V_Url as Url, m.N_IdApli as IdApli
from "SYS"."TBC_MENU" m inner join "SYS"."TBD_MENUPERFIL" mp on m.N_IdMenu = mp.N_IdMenu 
where m.N_IdMenu<> m.N_IdPadre and mp.N_IdPerfil =idperfil and  
N_IdPadre in (SELECT m.N_IdMenu
				FROM            "SYS"."TBC_MENU" m inner join "SYS"."TBD_MENUPERFIL" mp on m.N_IdMenu= mp.N_IdMenu 
where m.N_IdMenu= m.N_IdPadre and mp.N_IdPerfil =idperfil)
UNION all
select 2 as ID, m.N_IdMenu as IdMenu, m.V_Descripcion as Descripcion, 
m.N_IdPadre as IdPadre, m.N_Posicion as Posicion, m.V_Icono as Icono, m.S_Habilitado as Habilitado, 
m.V_Url as Url, m.N_IdApli as IdApli 
from "SYS"."TBC_MENU" m inner join "SYS"."TBD_MENUPERFIL" mp  on m.N_IdMenu= mp.N_IdMenu 
where mp.N_IdPerfil =idperfil and m.N_IdPadre in 
(select m.N_IdMenu 
from "SYS"."TBC_MENU"  m inner join "SYS"."TBD_MENUPERFIL" mp on m.N_IdMenu= mp.N_IdMenu
where mp.N_IdPerfil =idperfil and m.N_IdMenu<> m.N_IdPadre and  m.N_IdPadre in (SELECT     m.N_IdMenu
						FROM            "SYS"."TBC_MENU" m inner join "SYS"."TBD_MENUPERFIL" mp on m.N_IdMenu= mp.N_IdMenu 
						where m.N_IdMenu= m.N_IdPadre and mp.N_IdPerfil =idperfil )
)
)a 
	)b
);
return consulta;

end

$$;

