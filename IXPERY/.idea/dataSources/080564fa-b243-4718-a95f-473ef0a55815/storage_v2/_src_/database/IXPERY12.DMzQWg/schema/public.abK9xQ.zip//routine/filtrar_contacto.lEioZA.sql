create function filtrar_contacto(integer, character varying)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
if (
select count(*)
from "LOG"."TBC_CONTACTOEMPRESA" WHERE n_idempresa=$1 and v_nomcontacto like '%'||$2||'%')>0 then
data_json:=(
	select concat('{"46038":','[', 
		(select string_agg(registros||'',',') from (
			select row_to_json(a) as registros from (	
				
							select n_idcontacto AS "460381",(SELECT row_to_json(a) from(
								select distinct n_idempresa as "460091"
								from "LOG"."TBC_EMPRESA" WHERE n_idempresa=$1
								)a)AS "460382",v_nomcontacto AS "460383",v_apellpaterno AS "460384",
							v_apellmaterno AS "460385",v_direccion AS "460386",v_telefono AS "460387",s_estado AS "460388",
							v_ciudad AS "460389",v_cargo AS "4603810",v_dni AS "4603811",v_correo AS "4603812"
							from "LOG"."TBC_CONTACTOEMPRESA" WHERE n_idempresa=$1 and v_nomcontacto like '%'||$2||'%'

				)a
			)s
		 )
	 ,']}')
	);
else data_json=0;
	
end if;
return data_json;
end

$$;

