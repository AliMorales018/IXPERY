create function gen_eliminar(numtbl text, campos text)
  returns void
language plpgsql
as $$
DECLARE
consulta text;
esq varchar;
condicion text;
nomtbl text;
BEGIN
nomtbl:=(select distinct tabla from tabla_general where idtabla= cast(numtbl as integer));
esq:= (select distinct esquema from tabla_general where tabla= nomtbl);
condicion:= (select gen_where(nomtbl,campos));
consulta:= 'UPDATE '||'"'||esq||'"."'||nomtbl||'" set s_estado='||chr(39)||'0'||chr(39)||' where '||condicion;
execute(consulta); 
END;

$$;

