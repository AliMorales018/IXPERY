create function log_obtener_estado_tipo_json(codigo character varying)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
if (select count(*) from "LOG"."TBC_ESTADO"
					where v_cod= codigo) > 0then 
	data_json:=(
		select concat('[', 
			(select string_agg(registros||'',',') from (
				select row_to_json(a) as registros from (
					
					select N_IdEstado as IdEstado, V_NomEstado as NomEstado from "LOG"."TBC_ESTADO"
					where v_cod= codigo

					)a
			)s
		 )
	 ,']')
	);
else data_json=0;
	
end if;
return data_json;
end

$$;

