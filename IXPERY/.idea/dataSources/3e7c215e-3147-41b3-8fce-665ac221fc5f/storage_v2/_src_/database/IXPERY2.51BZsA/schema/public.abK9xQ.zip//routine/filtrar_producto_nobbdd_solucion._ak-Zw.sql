create function filtrar_producto_nobbdd_solucion(idsol integer)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
IF (select count(*) from "LOG"."TBC_SOLUCION" S
						inner join "LOG"."TBC_EQUIPO" E on S.n_idsolucion=E.n_idsolucion
						inner join "LOG"."TBD_PRODUCTOSOLUCION" PS on E.n_idequipo=PS.n_idequipo
						inner join "LOG"."TBC_PREREGISTROPRODUCTO" PP ON PS.n_idprodsol= PP.n_idprodsol
						where S.n_idsolucion=idsol  and PP.s_estado='1')>0 THEN
data_json:=(
	select concat('[', 
		(select string_agg(registros||'',',') from (
			select row_to_json(a) as registros from (

						select PP.n_idprereg AS "IDPREREGISTRO",PP.v_nomproducto AS "NOMPRODUCTO" from "LOG"."TBC_SOLUCION" S
						inner join "LOG"."TBC_EQUIPO" E on S.n_idsolucion=E.n_idsolucion
						inner join "LOG"."TBD_PRODUCTOSOLUCION" PS on E.n_idequipo=PS.n_idequipo
						inner join "LOG"."TBC_PREREGISTROPRODUCTO" PP ON PS.n_idprodsol= PP.n_idprodsol
						where S.n_idsolucion=idsol and PP.s_estado='1'
				)a
			)s
		 )
	 ,']')
	);
	ELSE data_json=0;
	END IF;
	return data_json;
end

$$;

