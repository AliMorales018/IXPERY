create function filtrar_proyecto_empresa(idempresa integer, nompy character varying)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
if (select count(*) FROM "LOG"."TBC_PROYECTO"
					WHERE s_estado='1' AND n_idempresa=idempresa and v_nomproyecto LIKE '%'||nompy||'%') > 0then 
	data_json:=(
		select concat('[', 
			(select string_agg(registros||'',',') from (
				select row_to_json(a) as registros from (

						select n_idproyecto as IDPROYECTO, v_nomproyecto AS NOMPROYECTO FROM "LOG"."TBC_PROYECTO"
						WHERE s_estado='1' AND n_idempresa=idempresa and v_nomproyecto LIKE '%'||nompy||'%'

					)a
				)s
			 )
		 ,']')
		);
else data_json =0;
end if;
	return data_json;
end

$$;

