create function gen_filtrar_like_empresa(numtbl text, campos text)
  returns text
language plpgsql
as $$
DECLARE
nomtbl text;
esquemacab varchar;
consulta varchar(4000);
condicion text;
camposalias text;
camposaliasnofk text;
camposaliasfk text;
campofk text;
idcampofkcab text;
idcampofkdet text;
data_json text;
campopk text;
cantfk integer;
consultajson text;
i integer;
consultabuilobject text;
consultafin text;
BEGIN

consultajson:='';
nomtbl:= (select distinct tabla from tabla_general where idtabla=cast (numtbl as integer));
esquemacab:=(select distinct esquema from tabla_general where idtabla=cast (numtbl as integer));
camposalias:=(select (string_agg(campo||'',','))from (
				select campo from tabla_general where idtabla=cast (numtbl as integer)
			)t);
			
if (select substring(campos,1,1))='1' then
--condicion:=(select gen_where_like(numtbl,campos));
consulta:= 'DROP TABLE IF EXISTS TBLTEMP;
			CREATE TEMP TABLE TBLTEMP AS select '||camposalias||' from "'||esquemacab||'"."'||nomtbl||'"
			WHERE n_idcliente>0';
end if;
if (select substring(campos,1,1))='2' then
--condicion:=(select gen_where_like(numtbl,campos));
consulta:='DROP TABLE IF EXISTS TBLTEMP;
			CREATE TEMP TABLE TBLTEMP AS select '||camposalias||' from "'||esquemacab||'"."'||nomtbl||'"
			WHERE n_idestado=2';
end if;
if (select substring(campos,1,1))='3' then
--condicion:=(select gen_where_like(numtbl,campos));
consulta:='DROP TABLE IF EXISTS TBLTEMP;
			CREATE TEMP TABLE TBLTEMP AS select '||camposalias||' from "'||esquemacab||'"."'||nomtbl||'"
			WHERE n_idproveedor>0';
end if;

campos:=(SELECT substring(campos,3,length(campos)));

if (select length(campos))>2 then 
	if (select substring(campos,1,1))!='/' then
	condicion:=(select gen_where_like(numtbl,campos));
	consulta:=consulta||' and '||condicion;
	end if;
end if;
	
execute(consulta);

--concatenar las no fk con alias
camposaliasnofk:=	(select (string_agg(campo||' as "'||idcampo||'"',',')) from (
					select campo, idcampo from tabla_general tg
					where tabla=nomtbl and campo not in (
						select nom_campo from tabla_general tg
						left join tabla_constraint() tc on tc.nom_campo=tg.campo and tc.nom_tabla=tg.tabla
						where tabla=nomtbl and tipo_constraint in('FOREIGN KEY')
						)
					)t
				 );
--generar json_build_object--------------------------------------------------------------------------------
cantfk:=(select COUNT(*) from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint='FOREIGN KEY');
i:=1;
consultabuilobject:='';

while cantfk>=i
loop

idcampofkcab:=(select split_part (
					(select string_agg(iddet||'',',') from (
						SELECT cast (t.idcab as int),tt.iddet from (
						select idcampo as idcab, nom_campo,references_table
						from tabla_constraint() tc
						inner join tabla_general tg on tc.nom_campo=tg.campo and tc.nom_tabla=tg.tabla
						where nom_tabla=nomtbl and tipo_constraint='FOREIGN KEY')t
						INNER JOIN 
						(select idcampo as iddet, nom_campo,references_table
						from tabla_constraint() tc
						inner join tabla_general tg on tc.nom_campo=tg.campo and tc.references_table=tg.tabla
						where nom_tabla=nomtbl and tipo_constraint='FOREIGN KEY') tt --and tc.nom_campo=tg.campo
						ON t.nom_campo=tt.nom_campo and t.references_table=tt.references_table
						order by idcab asc
						
						
						)t
			  		)
				,',',i));
				
campofk:=(select split_part (
				(select string_agg(campo||'',',') from (
				select campo
				from tabla_constraint() tc
				inner join tabla_general tg on tc.nom_campo=tg.campo and tc.nom_tabla=tg.tabla
				where nom_tabla=nomtbl and tipo_constraint='FOREIGN KEY' and tc.nom_campo=tg.campo
				--order by idcampo
			)t)
		,',',i));
		
idcampofkdet:=(select split_part(( select string_agg(idcampo||'',',') from (
					select idcampo
					from tabla_constraint() tc
					inner join tabla_general tg on tc.nom_campo=tg.campo and tc.nom_tabla=tg.tabla
					where nom_tabla=nomtbl and tipo_constraint='FOREIGN KEY' and tc.nom_campo=tg.campo
					--order by idcampo
				)t
		  ),',',i));
		
consultabuilobject:=consultabuilobject||', json_build_object('||chr(39)||idcampofkcab||chr(39)||',a.'||campofk||') as "'||idcampofkdet||'"';
i:=i+1;
end loop;

--fin generar json_build_object--------------------------------------------------------------------------------		  				
		
consultajson:='select (string_agg(fila_json||'||chr(39)||chr(39)||','||chr(39)||','||chr(39)||'))
				from (
						select row_to_json(u) as "fila_json"
					from(
						select '||camposaliasnofk;
						

consultafin:='from TBLTEMP a 
						)u
					)v;';
					
consultajson:=consultajson
				||consultabuilobject
				||consultafin;

execute(consultajson) into data_json;
data_json:=(select concat('{"'||numtbl||'":['||data_json||']}') );
return data_json;
end

$$;

