create function json_tabla_(nomtabla text, data_json json)
  returns SETOF record
language plpgsql
as $$
declare
sql text;
begin
	sql:= 'select * from json_populate_recordset(null::'||nomtabla||', '||chr(39)||data_json||chr(39)||')';
	return query execute sql;
end;
$$;

