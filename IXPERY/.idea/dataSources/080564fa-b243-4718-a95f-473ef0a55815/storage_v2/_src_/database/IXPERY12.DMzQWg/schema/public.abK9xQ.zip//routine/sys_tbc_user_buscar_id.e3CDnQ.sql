create function sys_tbc_user_buscar_id(valor integer)
  returns TABLE("ID USER" integer, login character varying, nombres character varying, "APELIDO PATERNO" character varying, "APELLIDO MATERNO" character varying, estado bit, clave character varying, "ID PERSONAL" integer)
language sql
as $$
select N_IdUser as "ID USER", V_Login AS "LOGIN", V_Nombres AS "NOMBRES", V_Paterno AS "APELIDO PATERNO", V_Materno AS "APELLIDO MATERNO",
S_Estado AS "ESTADO", V_Clave AS "CLAVE", N_IdPersonal AS "ID PERSONAL"
from "SYS"."TBC_USER" where N_IdUser=valor

$$;

