create function jsonf_jsont(data_jsonf json)
  returns TABLE(key text, value json)
language plpgsql
as $$
--TABLA CABECERA
declare numtbl oid;
declare nomtbl text;
--TABLA DETALLE
declare numtbldetalle oid;
declare nomtbldetalle text;
--declare numcampo int;
--declare nomcampo varchar;
declare consulta varchar(4000);
begin
numtbl:=(select data_jsonf ::json#>'{cabecera}');
nomtbl:=(select distinct tabla from tabla_general where idtabla= numtbl);
numtbldetalle:=(select data_jsonf ::json#>'{detalle}');
nomtbldetalle:=(select distinct tabla from tabla_general where idtabla= numtbldetalle);
--numcampo:=select data_jsonf ::json#>{'detalle'}
--nomcampo:= select tabla from tabla_general where idtabla= numtbl

consulta='
	SELECT * FROM json_each('||chr(39)||data_jsonf||chr(39)||') WHERE key <> ''cabecera''
	';
	if char_length(nomtbldetalle)>1 then
	consulta=consulta||'
	and key <> ''detalle''
	';
	end if;
	
consulta=consulta||'
	union all
	select ''cabecera'','||chr(39)||'"'||nomtbl||'"'||chr(39)||'
	';
if char_length(nomtbldetalle)>1 then
	consulta=consulta||'
	union all
	select ''detalle'','||chr(39)||'"'||nomtbldetalle||'"'||chr(39)||'
	';
	end if;
	return query execute(consulta)
	;
end;

$$;

