create function tabla_general()
  returns TABLE(idtabla oid, esquema character varying, tabla name, idcampo text, campo name, tipo_dato character varying)
language sql
as $$
select cl.oid as IDTABLA,eq.table_schema as ESQUEMA,cl.relname as TABLA, concat(atr.attrelid,atr.attnum) as IDCAMPO, atr.attname as CAMPO, eq.data_type as  TIPO_DATO
from pg_class cl
inner join pg_attribute atr on cl.oid=atr.attrelid
inner join information_schema.columns eq on atr.attname=eq.column_name and cl.relname=eq.table_name
where cl.relreplident ='d' and cl.relhasindex=true and atr.attstattarget=-1
order by cl.relname,cast(concat(atr.attrelid,atr.attnum) as numeric)

$$;

