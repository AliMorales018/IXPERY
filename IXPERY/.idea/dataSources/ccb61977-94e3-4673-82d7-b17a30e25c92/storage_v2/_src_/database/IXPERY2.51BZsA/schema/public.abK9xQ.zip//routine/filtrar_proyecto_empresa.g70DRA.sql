create function filtrar_proyecto_empresa(idempresa integer)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
if (select count(*) FROM "LOG"."TBC_PROYECTO"
					WHERE s_estado='1' AND n_idempresa=idempresa) > 0then 
	data_json:=(
		select concat('[', 
			(select string_agg(registros||'',',') from (
				select row_to_json(a) as registros from (

						select n_idproyecto as IDPROYECTO, v_nomproyecto AS NOMPROYECTO FROM "LOG"."TBC_PROYECTO"
						WHERE s_estado='1' AND n_idempresa=idempresa

					)a
				)s
			 )
		 ,']')
		);
else data_json =0;
end if;
	return data_json;
end
$$;

