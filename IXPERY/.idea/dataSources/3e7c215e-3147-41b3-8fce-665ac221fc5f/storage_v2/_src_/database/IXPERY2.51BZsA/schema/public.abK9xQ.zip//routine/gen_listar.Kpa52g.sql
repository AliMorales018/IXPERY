create function gen_listar(tabla text)
  returns SETOF record
language plpgsql
as $$
begin
execute 'select * from '||tabla;
end
$$;

