create function log_xtbd_perfil_buscar(idusuario integer, idaplicacion integer)
  returns TABLE("PERFIL" character varying, "ESTADO" bit, "APLICACION" character varying)
language plpgsql
as $$
begin
Select V_Perfil as "PERFIL", S_Estado AS "ESTADO", V_Aplicacion AS "APLICACION"
from "XXX"."TBC_PERFIL" p
inner join "XXX"."TBC_APLICACION" a on p.N_IdApli=a.N_IdApli
inner join "XXX"."TBD_PERFILUSER" pu on p.N_IdPerfil=pu.N_IdPerfil
inner join "XXX"."TBC_USER" u on pu.N_IdUser=u.N_IdUser
where S_Estado='1' and a.S_Estado='1' and a.N_IdApli=idaplicacion and u.N_IdUser=idusuario;
end
$$;

