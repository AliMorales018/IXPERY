create function sys_tbc_menu_por_aplicacion_perfil(idaplicacion integer, idperfil integer)
  returns TABLE("IdPerfil" integer, "IdMenu" integer, "Descripcion" text, "IdPadre" integer, "Posicion" integer, "Icono" character varying, "Habilitado" bit, "Url" character varying, "IdApli" integer)
language plpgsql
as $$
begin
select N_IdPerfil as "IdPerfil", m.N_IdMenu as "IdMenu", V_Descripcion as "Descripcion",
N_IdPadre as "IdPadre",N_Posicion as "Posicion", V_Icono as "Icono",S_Habilitado as "Habilitado",
V_Url as "Url", N_IdApli as "IdApli"
from SYS.TBC_MENU m
inner join SYS.TBD_MENUPERFIL mp on m.N_IdMenu=mp.N_IdMenu
where m.N_IdApli=idaplicacion and N_IdPerfil=idperfil;
end

$$;

