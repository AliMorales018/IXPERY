create function pruebalo()
  returns text
language sql
as $$
select 'HOLA MUNDO DESDE POSTGRESQL';

$$;

