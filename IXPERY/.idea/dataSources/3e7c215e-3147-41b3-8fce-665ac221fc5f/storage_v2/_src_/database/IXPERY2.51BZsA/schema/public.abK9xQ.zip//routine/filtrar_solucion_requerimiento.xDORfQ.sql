create function filtrar_solucion_requerimiento(idrq integer)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
IF (select count(*)
				from "LOG"."TBC_SOLUCION"
				where n_idrequerimiento=idrq)>0 THEN
data_json:=(
	select concat('[', 
		(select string_agg(registros||'',',') from (
			select row_to_json(a) as registros from (
				
				select n_idsolucion as idsolucion,v_nomsolucion as nomsolucion,d_fechacreacion as fechacreacion, v_encargadosol as encargado,v_descripcion as descripcion
				from "LOG"."TBC_SOLUCION"
				where n_idrequerimiento=idrq

				)a
			)s
		 )
	 ,']')
	);
	ELSE data_json=0;
	END IF;
	return data_json;
end

$$;

