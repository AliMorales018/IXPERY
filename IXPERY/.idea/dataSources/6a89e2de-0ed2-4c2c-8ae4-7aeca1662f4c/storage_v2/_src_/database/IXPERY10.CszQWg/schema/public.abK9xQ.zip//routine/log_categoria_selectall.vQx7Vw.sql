create function log_categoria_selectall()
  returns TABLE(data_json json)
language sql
as $$
select to_json(t)
from (
	select c.n_idcategoria as idcategoria, c.v_nomcategoria as nomcategoria, c.n_idfamilia as idfamilia
 	from "LOG"."TBC_CATEGORIA" c )t

$$;

