create function listar_empresa()
  returns text
language plpgsql
as $$
declare
data_json text;
begin
IF (select COUNT(*)
				from "LOG"."TBC_EMPRESA"
				WHERE s_estado='1' and n_idcliente>0 )>0 THEN
data_json:=(
	select concat('[', 
		(select string_agg(registros||'',',') from (
			select row_to_json(a) as registros from (
				
				select n_idempresa as IDEMPRESA,v_nomempresa as NOMEMPRESA, v_ruc AS RUC
				from "LOG"."TBC_EMPRESA"
				WHERE s_estado='1' and n_idcliente>0 

				)a
			)s
		 )
	 ,']')
	);
	ELSE data_json=0;
	END IF;
	return data_json;
end

$$;

