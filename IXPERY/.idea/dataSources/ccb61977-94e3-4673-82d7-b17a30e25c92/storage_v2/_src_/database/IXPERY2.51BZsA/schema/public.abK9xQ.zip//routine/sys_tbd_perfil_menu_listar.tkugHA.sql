create function sys_tbd_perfil_menu_listar(idapli integer, idperfil integer)
  returns TABLE("IDPERFIL" integer, "IDMENU" integer, "IDPADRE" integer, "DESCRIPCION" character varying, "CHECK" bit)
language plpgsql
as $$
BEGIN
select N_IdPerfil as "IDPERFIL", m.N_IdMenu as "IDMENU",N_IdPadre as "IDPADRE", V_Descripcion as "DESCRIPCION",
(case when N_IdPerfil=idperfil then convert(bit,1) else convert(bit,0)end) as "CHECK" 
from "SYS"."TBC_MENU" m
inner join "SYS"."TBD_MENUPERFIL" mp on m.N_IdMenu=mp.N_IdMenu
where N_IdApli=idapli and N_IdPerfil=idperfil;
end

$$;

