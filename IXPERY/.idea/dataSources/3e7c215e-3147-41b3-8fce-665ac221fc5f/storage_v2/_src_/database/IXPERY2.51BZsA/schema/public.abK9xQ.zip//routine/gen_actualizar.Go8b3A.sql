create function gen_actualizar(data_json text, campos text)
  returns void
language plpgsql
as $$
DECLARE
numtbl int;
nomtbl text;
objeto json;
esquemacab varchar;
consulta varchar(4000);
dato_set text;
condicion text;
esquema text;
BEGIN

numtbl:=(select json_object_keys(cast (data_json as json)));
nomtbl:=(select distinct tabla from tabla_general where idtabla= numtbl);
objeto:=(select ((select data_json ::json->cast(numtbl as text)))::json->0);
dato_set := (select gen_set(data_json));
condicion:=(select gen_where(nomtbl,campos));
esquema:=(SELECT distinct table_schema FROM information_schema.columns where table_name=nomtbl);

consulta:= 'update "'||esquema||'"."'||nomtbl||'" 
set '||dato_set||' 
where '||condicion;

execute consulta;

END;

$$;

