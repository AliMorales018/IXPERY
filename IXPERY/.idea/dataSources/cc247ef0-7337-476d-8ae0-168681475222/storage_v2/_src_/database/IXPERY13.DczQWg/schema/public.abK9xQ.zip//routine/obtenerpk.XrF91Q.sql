create function obtenerpk(character varying)
  returns TABLE(pk character varying)
language sql
as $$
SELECT column_name 
	FROM information_schema.key_column_usage
	WHERE TABLE_NAME=$1 and constraint_name='pk_'||lower($1)

$$;

