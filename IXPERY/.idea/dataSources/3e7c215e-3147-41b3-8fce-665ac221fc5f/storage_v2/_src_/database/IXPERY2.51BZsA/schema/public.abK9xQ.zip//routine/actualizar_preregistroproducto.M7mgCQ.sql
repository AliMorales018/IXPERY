create function actualizar_preregistroproducto(campos text)
  returns text
language plpgsql
as $$
--CAMPOS:=(n_idsolucion, n_idprereg, n_idproducto);  1,2,1;1,1,5;
declare
valores text;
idsol int;
idpreg int;
idprod int;
cont int;
i int;
longtiud int;

begin
cont:=1;
i:=1;

campos:=(select substring(campos,1,length(campos)-1));

longtiud:=(select length(campos));

while longtiud>=i
loop
	if (select substring (campos,i,1))=';' then
	cont:=cont+1;
	end if;

i:=i+1;
end loop;

i:=1;

while cont>=i
loop
	--idprodsol:=();

	valores:=( select split_part(campos,';',i) );
	idsol:=( select split_part(valores,',',1));--valores
	idpreg:=( select split_part(valores,',',2) );--valores
	idprod:=( select split_part(valores,',',3));--valores

	UPDATE "LOG"."TBC_PREREGISTROPRODUCTO"
	SET n_idproducto= idprod,s_estado='0'
	WHERE n_idprereg=idpreg and s_estado='1';

	UPDATE "LOG"."TBD_PRODUCTOSOLUCION"
	SET n_idprereg=idpreg
	WHERE  n_idproducto=idprod and s_estado='1';
i:=i+1;
end loop;
return 'actualizados';
end
--n_idsolucion, n_idprereg, n_idproducto
$$;

