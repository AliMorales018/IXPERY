create function filtrar_producto2parametros(idprodprov integer, nomprod text)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
IF (select count(*) from "LOG"."TBD_PRODUCTOPROVEEDOR" PP
						inner join "LOG"."TBC_PRODUCTO" P ON PP.n_idproducto=P.n_idproducto
						where v_nomproducto like '%'||nomprod||'%' and n_idprodprov=idprodprov)>0 THEN
data_json:=(
	select concat('[', 
		(select string_agg(registros||'',',') from (
			select row_to_json(a) as registros from (
				
						select n_idprodprov,P.n_idproducto, v_nomumed,n_codigo,v_nomproducto,v_modelo,v_marca
						from "LOG"."TBD_PRODUCTOPROVEEDOR" PP
						inner join "LOG"."TBC_PRODUCTO" P ON PP.n_idproducto=P.n_idproducto
						where v_nomproducto like '%'||nomprod||'%' and n_idprodprov=idprodprov
					
				)a
			)s
		 )
	 ,']')
	);
	ELSE data_json=0;
	END IF;
	return data_json;
end

$$;

