create function sys_aplicacion_perfil_menu_listar(idapli integer, idperfil integer)
  returns TABLE("IdMenu" integer, "IdPadre" integer, "Descripcion" text, "Check" bit)
language plpgsql
as $$
begin
select  m.N_IdMenu as "IdMenu", 
(case when N_IdPadre=m.N_IdMenu then null else N_IdPadre end) as "IdPadre",
V_Descripcion as "Descripcion", convert(bit,1) as "Check" 
from "SYS"."TBD_MENUPERFIL" MP inner join "SYS"."TBC_MENU" M on MP.N_idmenu = M.N_IdMenu  
where MP.S_estado='1' and M.N_idApli= idapli and MP.N_IdPerfil=idperfil
union
select M.N_idMenu as "IdMenu",
(case when M.N_IdPadre=M.N_IdMenu then null else N_IdPadre end) as "IdPadre",
V_Descripcion as "Descripcion", convert(bit,0) as "Descripcion" 
from SYS.TBC_MENU M
WHERE M.N_IdApli=idapli AND N_idMenu NOT IN (select m.N_IdMenu
from "SYS"."TBD_MENUPERFIL" MP inner join "SYS"."TBC_MENU" M on MP.N_idmenu = M.N_IdMenu  
where MP.S_estado='1' and M.N_idApli= idapli and N_IdPerfil=idperfil )
order by IdMenu;
end

$$;

