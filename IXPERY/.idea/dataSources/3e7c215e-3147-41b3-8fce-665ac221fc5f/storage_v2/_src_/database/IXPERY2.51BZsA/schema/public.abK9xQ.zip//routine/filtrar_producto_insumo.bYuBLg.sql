create function filtrar_producto_insumo(nomprod text)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
IF (select count(*) from "LOG"."TBC_PRODUCTO"
   where v_nomproducto like '%'||nomprod||'%')>0 THEN
data_json:=(
	select concat('[', 
		(select string_agg(registros||'',',') from (
			select row_to_json(a) as registros from (

						select n_idproducto as "IDPRODUCTO", v_nomproducto as "NOMPRODUCTO" 
						from "LOG"."TBC_PRODUCTO" 
						where v_nomproducto like '%'||nomprod||'%'	
				)a
			)s
		 )
	 ,']')
	);
	ELSE data_json=0;
	END IF;
	return data_json;
end

$$;

