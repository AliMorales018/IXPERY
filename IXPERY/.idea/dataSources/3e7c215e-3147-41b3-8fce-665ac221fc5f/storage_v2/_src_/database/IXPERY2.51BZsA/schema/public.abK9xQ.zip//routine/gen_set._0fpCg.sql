create function gen_set(data_json text)
  returns text
language plpgsql
as $$
DECLARE
numtbl int;
nomtbl text;
tipodato text;
tipodatoencrip text;
objeto json;
esquemacab varchar;
consulta varchar(4000);
actualizar text;
data_jsonf json;
objetofk json;
objetonofk json;
cantfk int;
camposfk text;
campovalorfk text;
valorfk text;
actualizarfk text;
actualizartodo text;
i int;
j int;

BEGIN
	data_jsonf:= (select cast(data_json as json));
	numtbl:=(select json_object_keys(data_jsonf));--"45920"
	nomtbl:=(select distinct tabla from tabla_general where idtabla= numtbl); --TBC_CATEGORIA
	objeto:=(select data_json ::json->cast(numtbl as text));
	tipodato:=(select (string_agg (''||campo||',' , ' ')) from tabla_general where tabla=nomtbl);
	tipodato:=substring(tipodato,1,length(tipodato)-1);
	tipodatoencrip:=(select (string_agg ('"'||idcampo||'" '|| tipo_dato||',' , ' ')) from tabla_general where tabla=nomtbl);
	tipodatoencrip:=substring(tipodatoencrip,1,length(tipodatoencrip)-1);
	esquemacab:=(SELECT distinct table_schema FROM information_schema.columns where table_name=nomtbl);
	i:=1;
	j:=1;
	valorfk:='';
	actualizarfk='';
	actualizar:='';
	camposfk:='';
	campovalorfk:='';
	actualizartodo:='';

objetonofk:=(
select ('{'||string_agg('"'||campo||'":'||value,',')||'}')::json from (
	select tg.campo,t.value  from tabla_general tg
		inner join (select * from json_each(objeto))t on tg.idcampo=t.key
	  WHERE campo not in (select nom_campo from (
			select nom_campo,nom_tabla  from tabla_constraint() where references_table in (
				select DISTINCT(references_table) from tabla_constraint() where nom_tabla=nomtbl and length(references_table)>0
				)
		)t inner join tabla_general tg on campo=nom_campo and nom_tabla=tabla where nom_tabla=nomtbl
		order by idcampo)
	)u
);

actualizar:= (select replace (
	(select (string_agg (''||tt.campo||'='||tt.value, ',')) from (
	select tg.campo,t.value  from tabla_general tg
	inner join (select * from json_each(objetonofk))t
	ON tg.campo=t.key where idcampo in ( select idcampo from tabla_general where tabla=nomtbl )
		
	)tt)
	,'"',chr(39)
	)
	);

cantfk:=(
		select count(*) as valor from tabla_general tg
		inner join (select * from json_each(objeto))t on tg.idcampo=t.key
	 	WHERE campo in ( select nom_campo from (
						select nom_campo,nom_tabla  from tabla_constraint() where references_table in (
							select DISTINCT(references_table) from tabla_constraint() where nom_tabla=nomtbl and length(references_table)>0
							)
						)t inner join tabla_general tg on campo=nom_campo and nom_tabla=tabla
						where nom_tabla=nomtbl
						order by idcampo)
);

if cantfk>0 then 

while cantfk>=j
loop
	camposfk:=(
				select (string_agg(campo||'',',')) from (
					select campo, key, t.value as valor from tabla_general tg
						inner join (select * from json_each(objeto))t on tg.idcampo=t.key
					  WHERE campo in (
								select nom_campo from (
									select nom_campo,nom_tabla  from tabla_constraint() where references_table in (
										select DISTINCT(references_table) from tabla_constraint() where nom_tabla=nomtbl and length(references_table)>0
											)
										)t inner join tabla_general tg on campo=nom_campo and nom_tabla=tabla
										where nom_tabla=nomtbl
										order by idcampo
									  )
						order by key desc

					)u
		);

		while cantfk>=i
		loop
			campovalorfk:=(
			select (string_agg(valor||'',',')) from (
						select campo, key, t.value as valor from tabla_general tg
							inner join (select * from json_each(objeto))t on tg.idcampo=t.key
						  WHERE campo in (
									select nom_campo from (
										select nom_campo,nom_tabla  from tabla_constraint() where references_table in (
											select DISTINCT(references_table) from tabla_constraint() where nom_tabla=nomtbl and length(references_table)>0
												)
											)t inner join tabla_general tg on campo=nom_campo and nom_tabla=tabla
											where nom_tabla=nomtbl
											order by idcampo
										  )
							order by key desc

						)u
		);
------------------------------------------------------------------------------------------------
		valorfk:=valorfk||(select value from json_each((
						select cast ((select split_part(campovalorfk,',',i)) as json)
					))
				 )||',';

		i:=i+1;
		end loop;
			
			if length(valorfk)>0 then
			valorfk:=(select replace ((valorfk),'"',chr(39)));
			--valorfk:=(select substring(valorfk,1,length(valorfk)-1));
			end if;

		actualizarfk:=actualizarfk||(
			select concat(
				(select split_part(camposfk,',',j))
				||'='
				||(select split_part(valorfk,',',j))
				||','
				)
		);
		
		j:=j+1;
		end loop;
end if;

if length(actualizarfk)>0  then
	actualizarfk:=(select substring(actualizarfk,1,length(actualizarfk)-1));
	--actualizarfk:=(select replace ((actualizarfk),'"',chr(39)));
	--actualizartodo:=(select concat(actualizar||','||actualizarfk));
	actualizartodo:=actualizartodo||actualizarfk||',';
	
end if;

if length(actualizar)>0  then
	--actualizarfk:=(select replace ((actualizarfk),'"',chr(39)));
	actualizartodo:=actualizartodo||actualizar||',';
end if;
actualizartodo:=(select substring(actualizartodo,1,length(actualizartodo)-1));
return actualizartodo;

END;

$$;

