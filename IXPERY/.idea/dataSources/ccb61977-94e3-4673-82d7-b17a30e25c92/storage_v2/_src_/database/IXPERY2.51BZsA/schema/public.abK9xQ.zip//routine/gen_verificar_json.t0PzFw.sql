create function gen_verificar_json(data_json text, OUT reporte text)
  returns text
language plpgsql
as $$
DECLARE
consulta text;
canttablas integer;
numreg integer;
--TABLA CABECERA
numtbl integer;
nomtbl text;
campostabla text;
tipodato text;
tipodatoencrip text;
arreglo text;
objeto text;
esquemacab varchar;
cantfk integer;
nomfk text;
cadena text;
i integer; --hasta el numero de resgistros que hayan en las tablas con fk
j integer; --hasta el numero de tablas que haya
numpk integer;
nompks text;
nompksencrip text;
pk integer;
campopk text;
campopk1 text;
consultauq text;
mensajeuq text;
mensajepk text;
cantuq integer;
campouq text;
campouqalias text;
nomuqsencrip text;
tipodatouqencrip text;
consulcantpk text;
cantpkrepet int;
consulcantuq text;
cantuqrepet int;
cantreg int;

BEGIN
j:=1;
reporte:='';
mensajepk='';
mensajeuq='';
--cantidad de tablas en el json
canttablas:=(select count(*) from json_each(cast (data_json as json)));
cantpkrepet=0;
cantuqrepet=0;

while canttablas>=j
loop

		--capturo el idtabla en el json
		numtbl:=(select split_part ((select (string_agg( dj.json_object_keys,',')) from (select json_object_keys(cast(data_json as json)))dj),',',j));
		--cambio el idtabla por el nombre de la tabla
		nomtbl:=(select distinct tabla from tabla_general where idtabla= numtbl);
		--cantidad de foreign key de la tabla
		cantfk:=(select count(tipo_constraint) from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY');
		--cambiar el nombre de las fk por los idcampo
		--nomfk:=(select idcampo from tabla_general where tabla=nomtbl and campo in (
		--		select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'));
		--capturo el esquema de la tabla
		esquemacab:=(SELECT distinct table_schema FROM information_schema.columns where table_name=nomtbl);
		--capturo los campos de la tabla concatenados con ','
		campostabla:=(select (string_agg (''||campo||',' , ' ')) from tabla_general where tabla=nomtbl);
		campostabla:=substring(campostabla,1,length(campostabla)-1);
		
		----verificar pk
		numpk:=(select count(nom_campo) from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint='PRIMARY KEY');
		nompks:=(select (string_agg(nom_campo||'',',')) from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint='PRIMARY KEY');
		nompksencrip:= (select (string_agg('"'||idcampo||'"',',')) from (
						select idcampo from tabla_general tg inner join tabla_constraint() tc on tg.tabla=tc.nom_tabla and tg.campo=tc.nom_campo
						where nom_tabla=nomtbl and tipo_constraint='PRIMARY KEY'
							)t);
		tipodatoencrip:= (select (string_agg('"'||idcampo||'" '|| tipo_dato||',' , ' ')) from (
						select idcampo,tipo_dato from tabla_general tg inner join tabla_constraint() tc on tg.tabla=tc.nom_tabla and tg.campo=tc.nom_campo
						where nom_tabla=nomtbl and tipo_constraint='PRIMARY KEY'
							)t);
		tipodatoencrip:=substring(tipodatoencrip,1,length(tipodatoencrip)-1);
		----fin verificar pk
		--verificar campos uq
		cantuq:=(select count(nom_campo) from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint='UNIQUE');
		campouq:=(select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint='UNIQUE');
		campouqalias:=(select substring(campouq,3,length(campouq)));

		nomuqsencrip:= (select (string_agg('"'||idcampo||'"',',')) from (
						select idcampo from tabla_general tg inner join tabla_constraint() tc on tg.tabla=tc.nom_tabla and tg.campo=tc.nom_campo
						where nom_tabla=nomtbl and tipo_constraint='UNIQUE'
							)t);
		tipodatouqencrip:= (select (string_agg('"'||idcampo||'" '|| tipo_dato||',' , ' ')) from (
						select idcampo,tipo_dato from tabla_general tg inner join tabla_constraint() tc on tg.tabla=tc.nom_tabla and tg.campo=tc.nom_campo
						where nom_tabla=nomtbl and tipo_constraint='UNIQUE'
									)t);
		tipodatouqencrip:=substring(tipodatouqencrip,1,length(tipodatouqencrip)-1);
		--fin verificar campos uq

		--identificar si la tabla tiene foreign key	
		if(cantfk)>=1 then

			--identificar si el contenido de la tabla es arreglo
			if (select substring(cast ((select data_json::json->(select split_part ((select (string_agg( dj.idtabla,',')) from (select json_object_keys
				(cast(data_json as json)) as idtabla)dj),',',j))) as text),1,1))='[' then
				--capturo el arreglo que pertenece al idtabla
				arreglo:=(select data_json::json->(select split_part ((select (string_agg( dj.idtabla,',')) from (select json_object_keys
						(cast(data_json as json)) as idtabla)dj),',',j)));
				arreglo:=(select concat('{"'||numtbl||'":'||arreglo||'}'));
						
				--numero de registros que envian en el arreglo de la tabla: (select cast (16441 as text))
				numreg:=(select json_array_length((select data_json::json->(select cast (numtbl as text))	))	);
				cadena:='';
				i:=0;	

				while numreg>i
				loop

					cadena:=cadena||(
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select concat ('{'||(string_agg ('"'||key||'":'||value, ','))||'}' )from ( --'[{"164411":1,"164412":2,"164413":"1","164414":"1"}]'
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select *from (
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select * from json_each ((
											select (	select value from  json_each((

												select cast ((arreglo)as json))    ))::json->i --hasta cantidad de registros
						))
					where key in (select idcampo from tabla_general where tabla=nomtbl
					and campo not in(select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))
					----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					union all
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
					select fk, value from (
					select fk,fkref from 
								(select campo as "campo1",idcampo as "fk" from tabla_general
								where tabla in (select nom_tabla from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY')
								and campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))t1
					inner join (
								select campo as "campo2",idcampo  as "fkref"from tabla_general
								where tabla in (select references_table from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY')
								and campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))t2
					on campo1=campo2)t

					inner join 
								(select key,value from json_each((
											select cast((
													select concat ('{',(select replace ((
															select replace((	select (string_agg(cast (t.value as text),','))
																				from (select value from json_each ((
																									select (	select value from  json_each((

																										select cast((arreglo)as json))
																												))::json->i --hasta cantidad de registros
																										))
																										where key in (select idcampo from tabla_general where 
																													tabla in (select nom_tabla from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY') and 
																													campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))
																										)t	  
																						 ),'{',''  )),'}',''  )),'}')
												) as json)))
								 )r2 on t.fkref =r2.key
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					)x order by key
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
					)y
					--fin cadena--------------------------------------------------------------------------------------------------------------------------
					)||',';
					----------------------------------------------------------------------------------------------------------------------
				i:=i+1;
				end loop;
				if (select length (cadena))>1 then
				cadena:=(select concat ('['||(select substring(cadena,1,length(cadena)-1))||']'));
				end if;
				
				--verificar
				pk:=1;
				campopk:='';
							
				while numpk>=pk
				loop

				campopk1:=(select split_part(nompks,',',pk))||'||'||chr(39);
				campopk:=campopk||(select '||'||campopk1||','||chr(39));
			
				pk:=pk+1;
				end loop;

				campopk:=(select substring(campopk,1,length(campopk)-3));
				campopk:=(select chr(39)||'('||chr(39)||campopk||chr(39)||')'||chr(39));

				consulta:='select concat('||chr(39)||'CamposPK: '||chr(39)||',(
					select (string_agg('||campopk||','||chr(39)||','||chr(39)||')) from (
						select '||nompks||' from "'||esquemacab||'"."'||nomtbl||'" where concat('||nompks||') in(
							select concat('||nompksencrip||') from json_populate_recordset(null::record,
							('||chr(39)||cadena||chr(39)||')
								)
								as ('||tipodatoencrip||'))
					)t
					))';
					
				consulcantpk:='select count (concat('||nompks||')) from "'||esquemacab||'"."'||nomtbl||'" where concat('||nompks||') in(
							select concat('||nompksencrip||') from json_populate_recordset(null::record,
							('||chr(39)||cadena||chr(39)||')
								)
								as ('||tipodatoencrip||'))';
				--fin verificar
				
				if cantuq>0 then
				--campos uq
				consultauq:= 'select concat( '||campouqalias||',(
	
				select (string_agg('||campouq||'||'||chr(39)||chr(39)||','||chr(39)||','||chr(39)||')) from (
					select '||campouq||' from "'||esquemacab||'"."'||nomtbl||'" where '||campouq|| ' in(
						select '||nomuqsencrip||' from json_populate_recordset(null::record,
						('||chr(39)||cadena||chr(39)||')
						)
						as ('||tipodatouqencrip||'))
				)t

				))';
				
				consulcantuq:='select count('||campouq||') from "'||esquemacab||'"."'||nomtbl||'" where '||campouq|| ' in(
						select '||nomuqsencrip||' from json_populate_recordset(null::record,
						('||chr(39)||cadena||chr(39)||')
						)
						as ('||tipodatouqencrip||'))';
				
				end if;
				--fin campouq
				
				
				
			--el contenido de la tabla es objeto
			else
			--capturo el objeto que pertenece al idtabla
			objeto:=(select concat('{"'||(select cast(numtbl as text))||'":['||	(		
				select (data_json)::json->(select cast (numtbl as text))
							),']}'			
						)
					 );

						cadena:='['||(
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select concat ('{'||(string_agg ('"'||key||'":'||value, ','))||'}' )from ( --'[{"164411":1,"164412":2,"164413":"1","164414":"1"}]'
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select *from (
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select * from json_each ((
											select (	select value from  json_each((

												select cast ((objeto)as json))    ))::json->0 --Solo un registro
						))
					where key in (select idcampo from tabla_general where tabla=nomtbl
					and campo not in(select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))
					----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					union all
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
					select fk, value from (
					select fk,fkref from 
								(select campo as "campo1",idcampo as "fk" from tabla_general
								where tabla in (select nom_tabla from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY')
								and campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))t1
					inner join (
								select campo as "campo2",idcampo  as "fkref"from tabla_general
								where tabla in (select references_table from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY')
								and campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))t2
					on campo1=campo2)t

					inner join 
								(select key,value from json_each((
											select cast((
													select concat ('{',(select replace ((
															select replace((	select (string_agg(cast (t.value as text),','))
																				from (select value from json_each ((
																									select (	select value from  json_each((

																										select cast((objeto)as json))
																												))::json->0 --Solo un registro
																										))
																										where key in (select idcampo from tabla_general where 
																													tabla in (select nom_tabla from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY') and 
																													campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))
																										)t	  
																						 ),'{',''  )),'}',''  )),'}')
												) as json)))
								 )r2 on t.fkref =r2.key
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					)x order by key
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
					)y
					--fin cadena--------------------------------------------------------------------------------------------------------------------------
					)||']';

				--verificar
				pk:=1;
				campopk:='';
							
				while numpk>=pk
				loop

				campopk1:=(select split_part(nompks,',',pk))||'||'||chr(39);
				campopk:=campopk||(select '||'||campopk1||','||chr(39));
			
				pk:=pk+1;
				end loop;

				campopk:=(select substring(campopk,1,length(campopk)-3));
				campopk:=(select chr(39)||'('||chr(39)||campopk||chr(39)||')'||chr(39));

				consulta:='select concat('||chr(39)||'CamposPK: '||chr(39)||',(
					select (string_agg('||campopk||','||chr(39)||','||chr(39)||')) from (
						select '||nompks||' from "'||esquemacab||'"."'||nomtbl||'" where concat('||nompks||') in(
							select concat('||nompksencrip||') from json_populate_recordset(null::record,
							('||chr(39)||cadena||chr(39)||')
								)
								as ('||tipodatoencrip||'))
					)t
					))';
				
				consulcantpk:='select count (concat('||nompks||')) from "'||esquemacab||'"."'||nomtbl||'" where concat('||nompks||') in(
							select concat('||nompksencrip||') from json_populate_recordset(null::record,
							('||chr(39)||cadena||chr(39)||')
								)
								as ('||tipodatoencrip||'))';
				--fin verificar

			end if;

		--la tabla no tiene foreign key	
		else

			--identificar si el contenido de la tabla es arreglo
			if (select substring(cast ((select data_json::json->(select split_part ((select (string_agg( dj.idtabla,',')) from (select json_object_keys
				(cast(data_json as json)) as idtabla)dj),',',j))) as text),1,1))='[' then

				--capturo el arreglo que pertenece al idtabla
				arreglo:=(select data_json::json->(select split_part ((select (string_agg( dj.idtabla,',')) from (select json_object_keys
				(cast(data_json as json)) as idtabla)dj),',',j)));
				--numero de registros que envian en el arreglo de la tabla
				--numreg:=(select json_array_length((select data_json::json->nomtbl)));

				--verificar
				pk:=1;
				campopk:='';
							
				while numpk>=pk
				loop

				campopk1:=(select split_part(nompks,',',pk))||'||'||chr(39);
				campopk:=campopk||(select '||'||campopk1||','||chr(39));
			
				pk:=pk+1;
				end loop;

				campopk:=(select substring(campopk,1,length(campopk)-3));
				campopk:=(select chr(39)||'('||chr(39)||campopk||chr(39)||')'||chr(39));

				consulta:='select concat('||chr(39)||'CamposPK: '||chr(39)||',(
					select (string_agg('||campopk||','||chr(39)||','||chr(39)||')) from (
						select '||nompks||' from "'||esquemacab||'"."'||nomtbl||'" where concat('||nompks||') in(
							select concat('||nompksencrip||') from json_populate_recordset(null::record,
							('||chr(39)||arreglo||chr(39)||')
								)
								as ('||tipodatoencrip||'))
					)t
					))';
				consulcantpk:='select count (concat('||nompks||')) from "'||esquemacab||'"."'||nomtbl||'" where concat('||nompks||') in(
							select concat('||nompksencrip||') from json_populate_recordset(null::record,
							('||chr(39)||arreglo||chr(39)||')
								)
								as ('||tipodatoencrip||'))';
					
				--fin verificar
				--campos uq
				if cantuq>0 then
				
				consultauq:= 'select concat( '||chr(39)||campouqalias||': '||chr(39)||',(
	
				select (string_agg('||campouq||'||'||chr(39)||chr(39)||','||chr(39)||','||chr(39)||')) from (
					select '||campouq||' from "'||esquemacab||'"."'||nomtbl||'" where '||campouq|| ' in(
						select '||nomuqsencrip||' from json_populate_recordset(null::record,
						('||chr(39)||arreglo||chr(39)||')
						)
						as ('||tipodatouqencrip||'))
				)t

				))';
				
				consulcantuq:='select count('||campouq||') from "'||esquemacab||'"."'||nomtbl||'" where '||campouq|| ' in(
						select '||nomuqsencrip||' from json_populate_recordset(null::record,
						('||chr(39)||arreglo||chr(39)||')
						)
						as ('||tipodatouqencrip||'))';
				
				
				end if;
				--fin campo uq

			--el contenido de la tabla es objeto
			else
				--capturo el objeto que pertenece al idtabla
				objeto:=(select data_json::json->(select split_part ((select (string_agg( dj.idtabla,',')) from (select json_object_keys
				(cast(data_json as json)) as idtabla)dj),',',j)));
				
				
				--verificar
				pk:=1;
				campopk:='';
							
				while numpk>=pk
				loop

				campopk1:=(select split_part(nompks,',',pk))||'||'||chr(39);
				campopk:=campopk||(select '||'||campopk1||','||chr(39));
			
				pk:=pk+1;
				end loop;

				campopk:=(select substring(campopk,1,length(campopk)-3));
				campopk:=(select chr(39)||'('||chr(39)||campopk||chr(39)||')'||chr(39));

				consulta:='select concat('||chr(39)||'CamposPK: '||chr(39)||',(
					select (string_agg('||campopk||','||chr(39)||','||chr(39)||')) from (
						select '||nompks||' from "'||esquemacab||'"."'||nomtbl||'" where concat('||nompks||') in(
							select concat('||nompksencrip||') from json_populate_recordset(null::record,
							('||chr(39)||'['||objeto||']'||chr(39)||')
								)
								as ('||tipodatoencrip||'))
					)t
					))';
					
				consulcantpk:='select count (concat('||nompks||')) from "'||esquemacab||'"."'||nomtbl||'" where concat('||nompks||') in(
							select concat('||nompksencrip||') from json_populate_recordset(null::record,
							('||chr(39)||'['||objeto||']'||chr(39)||')
								)
								as ('||tipodatoencrip||'))';
				--fin verificar
				--campos uq
				if cantuq>0 then
				
				consultauq:= 'select concat( '||chr(39)||campouqalias||': '||chr(39)||',(
	
				select (string_agg('||campouq||'||'||chr(39)||chr(39)||','||chr(39)||','||chr(39)||')) from (
					select '||campouq||' from "'||esquemacab||'"."'||nomtbl||'" where '||campouq|| ' in(
						select '||nomuqsencrip||' from json_populate_recordset(null::record,
						('||chr(39)||'['||objeto||']'||chr(39)||')
						)
						as ('||tipodatouqencrip||'))
				)t

				))';
				
				consulcantuq:= 'select count('||campouq||') from "'||esquemacab||'"."'||nomtbl||'" where '||campouq|| ' in(
						select '||nomuqsencrip||' from json_populate_recordset(null::record,
						('||chr(39)||'['||objeto||']'||chr(39)||')
						)
						as ('||tipodatouqencrip||'))';
				
				end if;
				--fin campo uq

			end if;

		end if;
		
		
		if numpk>0 then
		execute(consulcantpk) into cantpkrepet;
			if (cantpkrepet)>0 then
				execute(consulta) into mensajepk;
			end if;
		
		end if;
		
		
		if cantuq>0 then
		execute(consulcantuq) into cantuqrepet;
			if cantuqrepet>0 then
				execute(consultauq) into mensajeuq;
			end if;
		
		end if;
		
		if (cantuqrepet+cantpkrepet)>0 then
		reporte:=	reporte||chr(10)
					||mensajepk||chr(10)
					||mensajeuq;
		else
		reporte = 0;
		end if;
		
		--reporte:= cadena;
		mensajepk:='';
		mensajeuq:='';
		
		
j:=j+1;
end loop;
END;

$$;

