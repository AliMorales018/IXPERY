create function getfamilia()
  returns TABLE(idfamlia integer, nomfamilia character varying)
language sql
as $$
SELECT * FROM "LOG"."TBC_FAMILIA";

$$;

