create function gen_filtrar_prueba(numtbl text, campos text)
  returns text
language plpgsql
as $$
DECLARE
nomtbl text;
esquemacab varchar;
consulta varchar(4000);
condicion text;
camposalias text;
data_json text;
consultajson text;
BEGIN

consultajson:='';

--crear tabla temmporal
nomtbl:= (select distinct tabla from tabla_general where idtabla=cast (numtbl as integer));
esquemacab:=(select distinct esquema from tabla_general where idtabla=cast (numtbl as integer));
camposalias:=(select (string_agg(campo||'',','))from (
					select campo from tabla_general where idtabla=cast (numtbl as integer))t);
condicion:=(select gen_where(nomtbl,campos));

consulta:='DROP TABLE IF EXISTS TBLTEMP;
			CREATE TEMP TABLE TBLTEMP AS select '||camposalias||' from "'||esquemacab||'"."'||nomtbl||'"
			WHERE '||condicion;

consultajson:=(select gen_tabla_json(nomtbl,consulta));

execute(consultajson) into data_json;

data_json:=(select concat('{'||numtbl||':'||data_json||'}') );
return data_json;
end

$$;

