create function log_obtener_estado_tipo(codigo character varying)
  returns TABLE(idestado integer, nomestado character varying)
language plpgsql
as $$
begin
return query
select N_IdEstado as IdEstado, V_NomEstado as NomEstado from "LOG"."TBC_ESTADO"
where v_cod= codigo;
end

$$;

