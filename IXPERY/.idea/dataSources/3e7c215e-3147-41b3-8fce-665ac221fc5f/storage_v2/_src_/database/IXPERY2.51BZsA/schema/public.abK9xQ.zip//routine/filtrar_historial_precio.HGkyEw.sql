create function filtrar_historial_precio(idprov integer, idprod integer)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
IF (select count(*)
					from "LOG"."TBD_PRODUCTOPROVEEDOR"
					WHERE  n_idproducto=idprod and n_idproveedor=idprov)>0 THEN
data_json:=(
	select concat('[', 
		(select string_agg(registros||'',',') from (
			select row_to_json(a) as registros from (
				

					select n_idproducto as idproducto,d_fechainicio as fechainicio,d_fechafin as fechafin,n_preciocompra as n_preciocompra ,s_estado as estado
					from "LOG"."TBD_PRODUCTOPROVEEDOR"
					WHERE  n_idproducto=idprod and n_idproveedor=idprov
					ORDER BY d_fechainicio asc

				)a
			)s
		 )
	 ,']')
	);
	ELSE data_json=0;
	END IF;
	return data_json;
end

$$;

