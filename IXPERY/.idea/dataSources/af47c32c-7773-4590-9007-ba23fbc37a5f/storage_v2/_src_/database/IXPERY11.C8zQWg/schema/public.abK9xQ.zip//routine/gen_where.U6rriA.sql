create function gen_where(nomtabla text, campos text)
  returns text
language plpgsql
as $$
DECLARE
consulta varchar(4000);
camposverdaderos text;
condicion text;
i int;
j int;

BEGIN

j:=1;
camposverdaderos:='';

while (select length(split_part(campos,';',j)))>1
loop
	camposverdaderos:=camposverdaderos||
	(
	select split_part((
	select replace (
	campos,
	(select split_part ((select split_part(campos,';',j)),',',1)),
	(select campo from tabla_general where idcampo=(
	select split_part ((select split_part(campos,';',j)),',',1)
		))
	)),';',j)
	)||';';
j:=j+1;
end loop;

camposverdaderos:=substring(camposverdaderos,1,length(camposverdaderos)-1);

i:=1;
condicion:='';

while (select length(split_part(camposverdaderos,';',i)))>1
loop
	if(
		select tipo_dato from tabla_general
			where campo=(select split_part ((select split_part(camposverdaderos,';',i)),',',1)
			) and tabla= nomtabla
		) in ('integer', 'money') then

		condicion:=condicion||(select replace ((select split_part(camposverdaderos,';',i)),',','=')) || ' and ';

	else 
		condicion= condicion||(select concat ((select split_part ((select split_part(camposverdaderos,';',i)),',',1)),'=',(
				select concat (chr(39),(select split_part ((select split_part(camposverdaderos,';',i)),',',2)),chr(39))
				)))||' and ';
	end if;
i:=i+1;
end loop;
condicion:= substring (condicion,1,length(condicion)-4);
return condicion;
END;

$$;

