create function sys_tbc_menu_aplicacion_buscar(idmenu integer, idapli integer)
  returns TABLE("DESCRIPCION" character varying)
language plpgsql
as $$
Begin
Select V_Descripcion as "DESCRIPCION"
from "SYS"."TBC_MENU" m
inner join "SYS"."TBC_APLICACION" a on m.N_IdApli=a.N_IdApli
where S_Habilitado='1' and m.N_IdMenu=idMenu and a.N_IdApli=idapli;
end

$$;

