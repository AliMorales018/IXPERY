create function gen_retornaid(numtabla text)
  returns text
language plpgsql
as $$
declare
esquemacab text;
cantpk int;
mensaje text;
maxid integer;
campopk text;
nombretabla text;
cantreg int;

begin
nombretabla=(select distinct tabla from tabla_general where idtabla=cast (numtabla as int));

if exists(select tabla from tabla_general where tabla in (nombretabla)) then
	cantpk:= (select count(nom_campo) from tabla_constraint() where nom_tabla=nombretabla and tipo_constraint='PRIMARY KEY');
	if 	cantpk>1 then
		mensaje:='TIENE MÁS DE UNA PK';
	else 
		--obtener esquema
		esquemacab:= (select distinct esquema from tabla_general where tabla in (nombretabla));

		campopk:=(select nom_campo from tabla_constraint() where nom_tabla=nombretabla and tipo_constraint='PRIMARY KEY');
		execute 'select count(*) from "'||esquemacab||'"."'||nombretabla||'"'
		into cantreg;
		if cantreg=0 then
			maxid=1;
		else
			execute 'select max('||campopk||') from "'||esquemacab||'"."'||nombretabla||'"'
			into maxid;
			maxid:=maxid+1;
		end if;
		mensaje:= (select cast(maxid as text));
		
		
	end if;
else
	mensaje:= 'no existe la tabla';
end if;
return mensaje;

end

$$;

