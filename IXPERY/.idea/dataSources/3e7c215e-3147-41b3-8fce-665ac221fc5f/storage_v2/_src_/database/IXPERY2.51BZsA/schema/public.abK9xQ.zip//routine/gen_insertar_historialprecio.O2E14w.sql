create function gen_insertar_historialprecio(data_json text, OUT reporte text)
  returns text
language plpgsql
as $$
DECLARE
consulta text;
canttablas integer;
numreg integer;
--TABLA CABECERA
numtbl integer;
nomtbl text;
campostabla text;
tipodato text;
tipodatoencrip text;
arreglo text;
objeto text;
esquemacab varchar;
cantfk integer;
nomfk text;
cadena text;
i integer; --hasta el numero de resgistros que hayan en las tablas con fk
j integer; --hasta el numero de tablas que haya

--historial precio

numprod integer;
diaanterior date;
numprov integer;
fechaingresado date;
numprodprov integer;
ultimafechainicio date;

--fin histrial precio

BEGIN
j:=1;
--cantidad de tablas en el json
canttablas:=(select count(*) from json_each(cast (data_json as json)));

while canttablas>=j
loop

		--capturo el idtabla en el json
		numtbl:=(select split_part ((select (string_agg( dj.json_object_keys,',')) from (select json_object_keys(cast(data_json as json)))dj),',',j));
		--cambio el idtabla por el nombre de la tabla
		nomtbl:=(select distinct tabla from tabla_general where idtabla= numtbl);
		--cantidad de foreign key de la tabla
		cantfk:=(select count(tipo_constraint) from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY');
		--cambiar el nombre de las fk por los idcampo
		--nomfk:=(select idcampo from tabla_general where tabla=nomtbl and campo in (
		--		select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'));
		--capturo el nombre de los idcampo con el tipo de dato de la tabla
		tipodatoencrip:=(select (string_agg ('"'||idcampo||'" '|| tipo_dato||',' , ' ')) from tabla_general where tabla=nomtbl);
		tipodatoencrip:=substring(tipodatoencrip,1,length(tipodatoencrip)-1);
		--capturo el esquema de la tabla
		esquemacab:=(SELECT distinct table_schema FROM information_schema.columns where table_name=nomtbl);
		--capturo los campos de la tabla concatenados con ','
		campostabla:=(select (string_agg (''||campo||',' , ' ')) from tabla_general where tabla=nomtbl);
		campostabla:=substring(campostabla,1,length(campostabla)-1);

		--identificar si la tabla tiene foreign key	
		if(cantfk)>=1 then

			--identificar si el contenido de la tabla es arreglo
			if (select substring(cast ((select data_json::json->(select split_part ((select (string_agg( dj.idtabla,',')) from (select json_object_keys
				(cast(data_json as json)) as idtabla)dj),',',j))) as text),1,1))='[' then
				--capturo el arreglo que pertenece al idtabla
				arreglo:=(select data_json::json->(select split_part ((select (string_agg( dj.idtabla,',')) from (select json_object_keys
						(cast(data_json as json)) as idtabla)dj),',',j)));
				arreglo:=(select concat('{"'||numtbl||'":'||arreglo||'}'));
						
				--numero de registros que envian en el arreglo de la tabla: (select cast (16441 as text))
				numreg:=(select json_array_length((select data_json::json->(select cast (numtbl as text))	))	);
				cadena:='';
				i:=0;	

				while numreg>i
				loop

					cadena:=cadena||(
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select concat ('{'||(string_agg ('"'||key||'":'||value, ','))||'}' )from ( --'[{"164411":1,"164412":2,"164413":"1","164414":"1"}]'
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select *from (
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select * from json_each ((
											select (	select value from  json_each((

												select cast ((arreglo)as json))    ))::json->i --hasta cantidad de registros
						))
					where key in (select idcampo from tabla_general where tabla=nomtbl
					and campo not in(select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))
					----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					union all
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
					select fk, value from (
					select fk,fkref from 
								(select campo as "campo1",idcampo as "fk" from tabla_general
								where tabla in (select nom_tabla from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY')
								and campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))t1
					inner join (
								select campo as "campo2",idcampo  as "fkref"from tabla_general
								where tabla in (select references_table from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY')
								and campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))t2
					on campo1=campo2)t

					inner join 
								(select key,value from json_each((
											select cast((
													select concat ('{',(select replace ((
															select replace((	select (string_agg(cast (t.value as text),','))
																				from (select value from json_each ((
																									select (	select value from  json_each((

																										select cast((arreglo)as json))
																												))::json->i --hasta cantidad de registros
																										))
																										where key in (select idcampo from tabla_general where 
																													tabla in (select nom_tabla from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY') and 
																													campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))
																										)t	  
																						 ),'{',''  )),'}',''  )),'}')
												) as json)))
								 )r2 on t.fkref =r2.key
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					)x order by key
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
					)y
					--fin cadena--------------------------------------------------------------------------------------------------------------------------
					)||',';
					----------------------------------------------------------------------------------------------------------------------
				i:=i+1;
				end loop;
				if (select length (cadena))>1 then
				cadena:=(select concat ('['||(select substring(cadena,1,length(cadena)-1))||']'));
				end if;

				consulta:= 	'insert into "'||esquemacab||'"."'
							||nomtbl||'" ('||campostabla||')'
							||' select * from json_populate_recordset(null::record, '
							||chr(39)||cadena||chr(39)||') 
							as ('||tipodatoencrip||')
							;';

			--el contenido de la tabla es objeto
			else
			--capturo el objeto que pertenece al idtabla
			objeto:=(select concat('{"'||(select cast(numtbl as text))||'":['||	(		
				select (data_json)::json->(select cast (numtbl as text))
							),']}'			
						)
					 );

						cadena:='['||(
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select concat ('{'||(string_agg ('"'||key||'":'||value, ','))||'}' )from ( --'[{"164411":1,"164412":2,"164413":"1","164414":"1"}]'
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select *from (
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					select * from json_each ((
											select (	select value from  json_each((

												select cast ((objeto)as json))    ))::json->0 --Solo un registro
						))
					where key in (select idcampo from tabla_general where tabla=nomtbl
					and campo not in(select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))
					----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					union all
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
					select fk, value from (
					select fk,fkref from 
								(select campo as "campo1",idcampo as "fk" from tabla_general
								where tabla in (select nom_tabla from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY')
								and campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))t1
					inner join (
								select campo as "campo2",idcampo  as "fkref"from tabla_general
								where tabla in (select references_table from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY')
								and campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))t2
					on campo1=campo2)t

					inner join 
								(select key,value from json_each((
											select cast((
													select concat ('{',(select replace ((
															select replace((	select (string_agg(cast (t.value as text),','))
																				from (select value from json_each ((
																									select (	select value from  json_each((

																										select cast((objeto)as json))
																												))::json->0 --Solo un registro
																										))
																										where key in (select idcampo from tabla_general where 
																													tabla in (select nom_tabla from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY') and 
																													campo in (select nom_campo from tabla_constraint() where nom_tabla=nomtbl and tipo_constraint ='FOREIGN KEY'))
																										)t	  
																						 ),'{',''  )),'}',''  )),'}')
												) as json)))
								 )r2 on t.fkref =r2.key
					--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
					)x order by key
					------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
					)y
					--fin cadena--------------------------------------------------------------------------------------------------------------------------
					)||']';

					consulta:= 	'insert into "'||esquemacab||'"."'
							||nomtbl||'" ('||campostabla||')'
							||' select * from json_populate_recordset(null::record, '
							||chr(39)||cadena||chr(39)||') 
							as ('||tipodatoencrip||')
							;';

			end if;

		--la tabla no tiene foreign key

		end if;

numprod:=(
	select data_json::json#>'{46713,467132,461441}'
	);
	
numprov:=(
	select data_json::json#>'{46713,467133,459951}'
	);

--VALIDAR FECHA MAYOR A LA ULTIMA REGISTRADA
fechaingresado:=(
select cast(
		(select cast(
			(select data_json::json#>'{46713,467136}'
			) as text)
		 ) as date
	)

);

numprodprov:=(select n_idprodprov from "LOG"."TBD_PRODUCTOPROVEEDOR" WHERE n_idproveedor=numprov and n_idproducto=numprod and s_estado='1');

ultimafechainicio:=(
	select d_fechainicio from "LOG"."TBD_PRODUCTOPROVEEDOR" WHERE n_idproveedor=numprov and n_idproducto=numprod and s_estado='1'
	
);


--FIN VALIDAR FECHA MAYOR A LA ULTIMA REGISTRADA
if ultimafechainicio<fechaingresado then

		diaanterior:=(
			select cast(
			(select cast(
				(select cast(
					(select data_json::json#>'{46713,467136}'
					) as text)
				 ) as date) - '1 days'::interval
			 ) as date)
		);

		UPDATE "LOG"."TBD_PRODUCTOPROVEEDOR"
		SET d_fechafin=diaanterior,s_estado='0'
		WHERE n_idproducto=numprod and n_idproveedor=numprov and s_estado='1';

				execute(consulta);
				reporte:= 'insertados';
		
else reporte:='ingresar fecha mayor a la última registrada';

end if;
	j:=j+1;	
end loop;
END;

$$;

