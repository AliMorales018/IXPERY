create function pa_consultaprueba(xtabla text)
  returns SETOF record
language plpgsql
as $$
declare
sql text;
begin
sql := 'select * from "LOG".'||xtabla;
return query execute sql;
end;

$$;

