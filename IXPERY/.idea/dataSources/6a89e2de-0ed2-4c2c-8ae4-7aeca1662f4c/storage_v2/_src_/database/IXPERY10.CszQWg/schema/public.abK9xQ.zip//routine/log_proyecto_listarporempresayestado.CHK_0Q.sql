create function log_proyecto_listarporempresayestado(empresa integer)
  returns TABLE(id_proyecto integer, id_empresa integer, nom_proyecto character varying, jefe_proyecto character varying, fecha_inicio timestamp without time zone, fecha_fin timestamp without time zone, fecha_p_fin timestamp without time zone, tiempo_estim_coti integer, estado bit, inv_estim money, id_estado integer, cant_rq integer, fecha_registro timestamp without time zone, user_registro character varying)
language plpgsql
as $$
begin
return query
select N_IdProyecto as "ID_PROYECTO", PY.N_IdEmpresa as "ID_EMPRESA", V_NomProyecto as "NOM_PROYECTO", V_JefeProyecto
as "JEFE_PROYECTO", D_FechaInicio as "FECHA_INICIO", D_FechaFin as "FECHA_FIN",D_FechaPFinal as "FECHA_P_FIN",
N_TiempoEstimCoti as "TIEMPO_ESTIM_COTI", PY.S_Estado as "ESTADO", N_InverEstim as "INV_ESTIM", PY.N_IdEstado as "ID_ESTADO",
N_CantRQ as "CANT_RQ", D_FechaRegistro as "FECHA_REGISTRO",
PY.V_UserRegistro as "USER_REGISTRO"
from "LOG"."TBC_PROYECTO" PY
inner join "LOG"."TBC_EMPRESA" EMP on PY.N_IdEmpresa=EMP.N_IdEmpresa
where PY.S_Estado='1' and EMP.N_IdEmpresa=empresa;
end

$$;

