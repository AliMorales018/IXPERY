create function filtrar_requerimiento_proyecto(idproyecto integer)
  returns text
language plpgsql
as $$
declare
data_json text;
begin
if (select count(*) FROM "LOG"."TBC_REQUERIMIENTO"
				WHERE s_estado='1' AND n_idproyecto=idproyecto)>0 then
data_json:=(
	select concat('[', 
		(select string_agg(registros||'',',') from (
			select row_to_json(a) as registros from (

				select n_idrequerimiento as IDREQUERIMIENTO, v_nomrequerimiento AS NOMREQUERIMIENTO FROM "LOG"."TBC_REQUERIMIENTO"
				WHERE s_estado='1' AND n_idproyecto=idproyecto
				
				)a
			)s
		 )
	 ,']')
	);
else data_json=0;
	
end if;
return data_json;
end
$$;

