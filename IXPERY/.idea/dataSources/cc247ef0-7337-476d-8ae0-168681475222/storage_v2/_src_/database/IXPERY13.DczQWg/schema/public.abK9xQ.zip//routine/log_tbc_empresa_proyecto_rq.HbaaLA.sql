create function log_tbc_empresa_proyecto_rq(idempresa integer, idproyecto integer)
  returns TABLE("ID_RQ" integer, "ID_PROYECTO" integer, "NOM_RQ" character varying, "NIVEL" character varying, "ESTADO" bit, "ID_ESTADO" integer, "FECHA_REGISTRO" timestamp without time zone, "USER_REGISTRO" character varying)
language plpgsql
as $$
begin
select N_IdRequerimiento AS "ID_RQ",RQ.N_IdProyecto AS "ID_PROYECTO",V_NomRequerimiento AS "NOM_RQ",V_Nivel AS "NIVEL",
RQ.S_EstadoAS "ESTADO", RQ.N_IdEstado AS "ID_ESTADO",RQ.D_FechaRegistro AS "FECHA_REGISTRO",
RQ.V_UserRegistro AS "USER_REGISTRO"
from LOG.TBC_REQUERIMIENTO RQ
inner join log.TBC_PROYECTO PY on RQ.N_IdProyecto=PY.N_IdProyecto
inner join log.TBC_EMPRESA EMP on PY.N_IdEmpresa=EMP.N_IdEmpresa
WHERE EMP.N_IdEmpresa=idempresa AND PY.N_IdProyecto=idproyecto;
end
$$;

