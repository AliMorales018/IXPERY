create function log_proyecto_listar_fecha(fecinicio timestamp without time zone, fecfin timestamp without time zone)
  returns TABLE(id_proyecto integer, id_empresa integer, nom_proyecto character varying, jefe_proyecto character varying, fecha_inicio timestamp without time zone, fecha_fin timestamp without time zone, fecha_p_fin timestamp without time zone, tiempo_estim_coti integer, estado bit, inv_estim money, id_estado bit, cant_rq integer, fecha_registro timestamp without time zone, user_registro character varying)
language plpgsql
as $$
begin
select N_IdProyecto AS "ID_PROYECTO", PY.N_IdEmpresa as "ID_EMPRESA", V_NomProyecto AS "NOM_PROYECTO",
V_JefeProyecto AS "JEFE_PROYECTO",D_FechaInicio AS "FECHA_INICIO", D_FechaFin AS "FECHA_FIN",D_FechaPFinal AS "FECHA_P_FIN",
N_TiempoEstimCoti AS "TIEMPO_ESTIM_COTI", PY.S_Estado AS "ESTADO", N_InverEstim AS "INV_ESTIM", PY.N_IdEstado AS "ID_ESTADO",
N_CantRQ AS "CANT_RQ", D_FechaRegistro AS "FECHA_REGISTRO", PY.V_UserRegistro AS "USER_REGISTRO"
from log.TBC_PROYECTO PY
where PY.S_Estado=1 and D_FechaInicio between fecinicio and fecfin;
end
$$;

